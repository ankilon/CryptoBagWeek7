package com.example.cryptobag;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.example.cryptobag.Entities.Coin;
import com.example.cryptobag.Entities.CoinLoreResponse;
import com.google.gson.Gson;

import java.util.List;

public class DetailedActivity extends AppCompatActivity {
private static final String TAG = "DetailedActivity";
    Gson gson = new Gson();
    CoinLoreResponse coinLoreResponse = gson.fromJson(CoinLoreResponse.myString, CoinLoreResponse .class);
    List<Coin> coins = coinLoreResponse.getData();
    Context context;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detailed);

        Intent intent = getIntent();
        int mPosition = 0;
        if(intent.getExtras() != null)

        {
            Bundle extra = intent.getExtras();
            mPosition = extra.getInt("pos");
        }

        DetailFragment fragment = new DetailFragment();
        Bundle bundle = new Bundle();
        bundle.putInt("pos", mPosition);
        fragment.setArguments(bundle);
        FragmentManager myManager = getSupportFragmentManager();
        FragmentTransaction myTransaction = myManager.beginTransaction();
        myTransaction.replace(R.id.tablet_coinDetails, fragment);
        myTransaction.commit();
    }
}
