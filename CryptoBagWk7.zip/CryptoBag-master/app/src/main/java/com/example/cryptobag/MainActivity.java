package com.example.cryptobag;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.cryptobag.Entities.Coin;
import com.example.cryptobag.Entities.CoinLoreResponse;
import com.google.gson.Gson;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    String textToDisplay = "Here is my text";

    // Put initial data into the word list.



    private RecyclerView currencyList;
    private CoinListAdapter cAdapter;
    private RecyclerView.LayoutManager layoutManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Gson gson = new Gson();
        CoinLoreResponse coinLoreResponse = gson.fromJson(CoinLoreResponse.myString, CoinLoreResponse .class);
        List<Coin> coins = coinLoreResponse.getData();


        // Get a handle to the RecyclerView.
        currencyList = findViewById(R.id.coinList);
        if(currencyList != null) {
            // Create an adapter and supply the data to be displayed.
            cAdapter = new CoinListAdapter(this, coins);
            // Connect the adapter with the RecyclerView.
            currencyList.setAdapter(cAdapter);
            // Give the RecyclerView a default layout manager.
            currencyList.setLayoutManager(new LinearLayoutManager(this));


        }
    }


}
