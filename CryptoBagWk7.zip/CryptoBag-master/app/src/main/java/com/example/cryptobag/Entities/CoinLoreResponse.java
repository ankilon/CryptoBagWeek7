package com.example.cryptobag.Entities;

import java.util.List;

import com.google.gson.Gson;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class CoinLoreResponse {

    @SerializedName("data")
    @Expose
    private List<Coin> data = null;
    @SerializedName("info")
    @Expose
    private Info info;

    public static String myString = "{\n" +
                "  \"data\": [\n" +
                "    {\n" +
                "      \"id\": \"90\",\n" +
                "      \"symbol\": \"BTC\",\n" +
                "      \"name\": \"Bitcoin\",\n" +
                "      \"nameid\": \"bitcoin\",\n" +
                "      \"rank\": 1,\n" +
                "      \"price_usd\": \"6446.14\",\n" +
                "      \"percent_change_24h\": \"7.44\",\n" +
                "      \"percent_change_1h\": \"0.29\",\n" +
                "      \"percent_change_7d\": \"3.15\",\n" +
                "      \"price_btc\": \"1.00\",\n" +
                "      \"market_cap_usd\": \"117842919413.86\",\n" +
                "      \"volume24\": 28623747053.10935,\n" +
                "      \"volume24a\": 21919286872.30901,\n" +
                "      \"csupply\": \"18281159.00\",\n" +
                "      \"tsupply\": \"18281159\",\n" +
                "      \"msupply\": \"21000000\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"80\",\n" +
                "      \"symbol\": \"ETH\",\n" +
                "      \"name\": \"Ethereum\",\n" +
                "      \"nameid\": \"ethereum\",\n" +
                "      \"rank\": 2,\n" +
                "      \"price_usd\": \"131.96\",\n" +
                "      \"percent_change_24h\": \"3.73\",\n" +
                "      \"percent_change_1h\": \"-0.07\",\n" +
                "      \"percent_change_7d\": \"1.53\",\n" +
                "      \"price_btc\": \"0.020446\",\n" +
                "      \"market_cap_usd\": \"14541630650.33\",\n" +
                "      \"volume24\": 9749114880.65384,\n" +
                "      \"volume24a\": 8072074905.640596,\n" +
                "      \"csupply\": \"110196485.00\",\n" +
                "      \"tsupply\": \"110196485\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"58\",\n" +
                "      \"symbol\": \"XRP\",\n" +
                "      \"name\": \"XRP\",\n" +
                "      \"nameid\": \"ripple\",\n" +
                "      \"rank\": 3,\n" +
                "      \"price_usd\": \"0.172228\",\n" +
                "      \"percent_change_24h\": \"3.09\",\n" +
                "      \"percent_change_1h\": \"0.34\",\n" +
                "      \"percent_change_7d\": \"10.60\",\n" +
                "      \"price_btc\": \"0.000027\",\n" +
                "      \"market_cap_usd\": \"7390224691.42\",\n" +
                "      \"volume24\": 1585011504.7726831,\n" +
                "      \"volume24a\": 1515882493.3677511,\n" +
                "      \"csupply\": \"42909539227.00\",\n" +
                "      \"tsupply\": \"99991841593\",\n" +
                "      \"msupply\": \"100000000000\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"518\",\n" +
                "      \"symbol\": \"USDT\",\n" +
                "      \"name\": \"Tether\",\n" +
                "      \"nameid\": \"tether\",\n" +
                "      \"rank\": 4,\n" +
                "      \"price_usd\": \"1.00\",\n" +
                "      \"percent_change_24h\": \"-0.62\",\n" +
                "      \"percent_change_1h\": \"-0.06\",\n" +
                "      \"percent_change_7d\": \"-0.15\",\n" +
                "      \"price_btc\": \"0.000155\",\n" +
                "      \"market_cap_usd\": \"4056828670.81\",\n" +
                "      \"volume24\": 34542160263.15912,\n" +
                "      \"volume24a\": 26569701977.57234,\n" +
                "      \"csupply\": \"4049107372.00\",\n" +
                "      \"tsupply\": \"4049107372\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"2321\",\n" +
                "      \"symbol\": \"BCH\",\n" +
                "      \"name\": \"Bitcoin Cash\",\n" +
                "      \"nameid\": \"bitcoin-cash\",\n" +
                "      \"rank\": 5,\n" +
                "      \"price_usd\": \"219.41\",\n" +
                "      \"percent_change_24h\": \"4.34\",\n" +
                "      \"percent_change_1h\": \"-0.18\",\n" +
                "      \"percent_change_7d\": \"1.59\",\n" +
                "      \"price_btc\": \"0.033995\",\n" +
                "      \"market_cap_usd\": \"4024830440.97\",\n" +
                "      \"volume24\": 2165383554.3892856,\n" +
                "      \"volume24a\": 1895298351.795239,\n" +
                "      \"csupply\": \"18343840.00\",\n" +
                "      \"tsupply\": \"18343840\",\n" +
                "      \"msupply\": \"21000000\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"33234\",\n" +
                "      \"symbol\": \"BCHSV\",\n" +
                "      \"name\": \"Bitcoin SV\",\n" +
                "      \"nameid\": \"bitcoin-cash-sv\",\n" +
                "      \"rank\": 6,\n" +
                "      \"price_usd\": \"166.51\",\n" +
                "      \"percent_change_24h\": \"9.41\",\n" +
                "      \"percent_change_1h\": \"0.31\",\n" +
                "      \"percent_change_7d\": \"-0.10\",\n" +
                "      \"price_btc\": \"0.025798\",\n" +
                "      \"market_cap_usd\": \"3053919202.27\",\n" +
                "      \"volume24\": 1838957520.378188,\n" +
                "      \"volume24a\": 1212300816.7394037,\n" +
                "      \"csupply\": \"18341277.00\",\n" +
                "      \"tsupply\": \"21000000\",\n" +
                "      \"msupply\": \"21000000\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"1\",\n" +
                "      \"symbol\": \"LTC\",\n" +
                "      \"name\": \"Litecoin\",\n" +
                "      \"nameid\": \"litecoin\",\n" +
                "      \"rank\": 7,\n" +
                "      \"price_usd\": \"38.85\",\n" +
                "      \"percent_change_24h\": \"3.08\",\n" +
                "      \"percent_change_1h\": \"0.67\",\n" +
                "      \"percent_change_7d\": \"1.60\",\n" +
                "      \"price_btc\": \"0.006019\",\n" +
                "      \"market_cap_usd\": \"2510406078.92\",\n" +
                "      \"volume24\": 2864080584.3809323,\n" +
                "      \"volume24a\": 2080825400.9986234,\n" +
                "      \"csupply\": \"64619858.00\",\n" +
                "      \"tsupply\": \"64619858\",\n" +
                "      \"msupply\": \"84000000\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"2679\",\n" +
                "      \"symbol\": \"EOS\",\n" +
                "      \"name\": \"EOS\",\n" +
                "      \"nameid\": \"eos\",\n" +
                "      \"rank\": 8,\n" +
                "      \"price_usd\": \"2.22\",\n" +
                "      \"percent_change_24h\": \"3.35\",\n" +
                "      \"percent_change_1h\": \"-0.04\",\n" +
                "      \"percent_change_7d\": \"-1.22\",\n" +
                "      \"price_btc\": \"0.000343\",\n" +
                "      \"market_cap_usd\": \"2059014846.46\",\n" +
                "      \"volume24\": 2242907982.901825,\n" +
                "      \"volume24a\": 1630699254.0337012,\n" +
                "      \"csupply\": \"929000281.00\",\n" +
                "      \"tsupply\": \"1006245120\",\n" +
                "      \"msupply\": \"1006245120\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"2710\",\n" +
                "      \"symbol\": \"BNB\",\n" +
                "      \"name\": \"Binance Coin\",\n" +
                "      \"nameid\": \"binance-coin\",\n" +
                "      \"rank\": 9,\n" +
                "      \"price_usd\": \"12.23\",\n" +
                "      \"percent_change_24h\": \"5.26\",\n" +
                "      \"percent_change_1h\": \"-0.01\",\n" +
                "      \"percent_change_7d\": \"2.59\",\n" +
                "      \"price_btc\": \"0.001895\",\n" +
                "      \"market_cap_usd\": \"1902658028.79\",\n" +
                "      \"volume24\": 245235939.6869611,\n" +
                "      \"volume24a\": 174109388.4677768,\n" +
                "      \"csupply\": \"155536713.00\",\n" +
                "      \"tsupply\": \"192443301\",\n" +
                "      \"msupply\": \"200000000\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"3682\",\n" +
                "      \"symbol\": \"XTZ\",\n" +
                "      \"name\": \"Tezos\",\n" +
                "      \"nameid\": \"tezos\",\n" +
                "      \"rank\": 10,\n" +
                "      \"price_usd\": \"1.59\",\n" +
                "      \"percent_change_24h\": \"4.31\",\n" +
                "      \"percent_change_1h\": \"-0.10\",\n" +
                "      \"percent_change_7d\": \"-0.76\",\n" +
                "      \"price_btc\": \"0.000246\",\n" +
                "      \"market_cap_usd\": \"1049027446.89\",\n" +
                "      \"volume24\": 76090047.61057001,\n" +
                "      \"volume24a\": 59899315.81275347,\n" +
                "      \"csupply\": \"660373612.00\",\n" +
                "      \"tsupply\": \"763306930\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"33833\",\n" +
                "      \"symbol\": \"LEO\",\n" +
                "      \"name\": \"UNUS SED LEO\",\n" +
                "      \"nameid\": \"unus-sed-leo\",\n" +
                "      \"rank\": 11,\n" +
                "      \"price_usd\": \"1.04\",\n" +
                "      \"percent_change_24h\": \"1.74\",\n" +
                "      \"percent_change_1h\": \"-0.08\",\n" +
                "      \"percent_change_7d\": \"1.25\",\n" +
                "      \"price_btc\": \"0.000161\",\n" +
                "      \"market_cap_usd\": \"1036929667.66\",\n" +
                "      \"volume24\": 2318944.0280456594,\n" +
                "      \"volume24a\": 1365280.842864145,\n" +
                "      \"csupply\": \"999498893.00\",\n" +
                "      \"tsupply\": \"999498893\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"89\",\n" +
                "      \"symbol\": \"XLM\",\n" +
                "      \"name\": \"Stellar\",\n" +
                "      \"nameid\": \"stellar\",\n" +
                "      \"rank\": 12,\n" +
                "      \"price_usd\": \"0.040219\",\n" +
                "      \"percent_change_24h\": \"3.92\",\n" +
                "      \"percent_change_1h\": \"-0.34\",\n" +
                "      \"percent_change_7d\": \"3.50\",\n" +
                "      \"price_btc\": \"0.000006\",\n" +
                "      \"market_cap_usd\": \"815773495.35\",\n" +
                "      \"volume24\": 261867367.55287468,\n" +
                "      \"volume24a\": 250604318.40854663,\n" +
                "      \"csupply\": \"20283516588.00\",\n" +
                "      \"tsupply\": \"104303927518\",\n" +
                "      \"msupply\": \"104303927518\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"28\",\n" +
                "      \"symbol\": \"XMR\",\n" +
                "      \"name\": \"Monero\",\n" +
                "      \"nameid\": \"monero\",\n" +
                "      \"rank\": 13,\n" +
                "      \"price_usd\": \"46.61\",\n" +
                "      \"percent_change_24h\": \"4.45\",\n" +
                "      \"percent_change_1h\": \"0.72\",\n" +
                "      \"percent_change_7d\": \"11.81\",\n" +
                "      \"price_btc\": \"0.007221\",\n" +
                "      \"market_cap_usd\": \"800443556.45\",\n" +
                "      \"volume24\": 116453599.50256775,\n" +
                "      \"volume24a\": 104748583.26498315,\n" +
                "      \"csupply\": \"17174299.00\",\n" +
                "      \"tsupply\": \"17174299\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"257\",\n" +
                "      \"symbol\": \"ADA\",\n" +
                "      \"name\": \"Cardano\",\n" +
                "      \"nameid\": \"cardano\",\n" +
                "      \"rank\": 14,\n" +
                "      \"price_usd\": \"0.029817\",\n" +
                "      \"percent_change_24h\": \"4.44\",\n" +
                "      \"percent_change_1h\": \"0.10\",\n" +
                "      \"percent_change_7d\": \"4.02\",\n" +
                "      \"price_btc\": \"0.000005\",\n" +
                "      \"market_cap_usd\": \"773067602.69\",\n" +
                "      \"volume24\": 71350039.50165908,\n" +
                "      \"volume24a\": 61939661.6740838,\n" +
                "      \"csupply\": \"25927070538.00\",\n" +
                "      \"tsupply\": \"31112483745\",\n" +
                "      \"msupply\": \"45000000000\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"2713\",\n" +
                "      \"symbol\": \"TRX\",\n" +
                "      \"name\": \"TRON\",\n" +
                "      \"nameid\": \"tron\",\n" +
                "      \"rank\": 15,\n" +
                "      \"price_usd\": \"0.011471\",\n" +
                "      \"percent_change_24h\": \"5.12\",\n" +
                "      \"percent_change_1h\": \"0.06\",\n" +
                "      \"percent_change_7d\": \"3.37\",\n" +
                "      \"price_btc\": \"0.000002\",\n" +
                "      \"market_cap_usd\": \"764914382.70\",\n" +
                "      \"volume24\": 783910008.0483857,\n" +
                "      \"volume24a\": 720241035.1808786,\n" +
                "      \"csupply\": \"66682072191.00\",\n" +
                "      \"tsupply\": \"99000000000\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"2751\",\n" +
                "      \"symbol\": \"LINK\",\n" +
                "      \"name\": \"ChainLink\",\n" +
                "      \"nameid\": \"chainlink\",\n" +
                "      \"rank\": 16,\n" +
                "      \"price_usd\": \"2.14\",\n" +
                "      \"percent_change_24h\": \"3.86\",\n" +
                "      \"percent_change_1h\": \"0.30\",\n" +
                "      \"percent_change_7d\": \"-0.48\",\n" +
                "      \"price_btc\": \"0.000331\",\n" +
                "      \"market_cap_usd\": \"747496637.98\",\n" +
                "      \"volume24\": 184100827.07358515,\n" +
                "      \"volume24a\": 148716509.72129935,\n" +
                "      \"csupply\": \"350000000.00\",\n" +
                "      \"tsupply\": \"1000000000\",\n" +
                "      \"msupply\": \"1000000000 \"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"8\",\n" +
                "      \"symbol\": \"DASH\",\n" +
                "      \"name\": \"Dash\",\n" +
                "      \"nameid\": \"dash\",\n" +
                "      \"rank\": 17,\n" +
                "      \"price_usd\": \"65.46\",\n" +
                "      \"percent_change_24h\": \"5.13\",\n" +
                "      \"percent_change_1h\": \"-0.04\",\n" +
                "      \"percent_change_7d\": \"-3.48\",\n" +
                "      \"price_btc\": \"0.010142\",\n" +
                "      \"market_cap_usd\": \"614858258.99\",\n" +
                "      \"volume24\": 520698665.48328495,\n" +
                "      \"volume24a\": 450461308.66710806,\n" +
                "      \"csupply\": \"9393253.00\",\n" +
                "      \"tsupply\": \"9393253\",\n" +
                "      \"msupply\": \"18900000\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"118\",\n" +
                "      \"symbol\": \"ETC\",\n" +
                "      \"name\": \"Ethereum Classic\",\n" +
                "      \"nameid\": \"ethereum-classic\",\n" +
                "      \"rank\": 18,\n" +
                "      \"price_usd\": \"4.95\",\n" +
                "      \"percent_change_24h\": \"1.66\",\n" +
                "      \"percent_change_1h\": \"0.33\",\n" +
                "      \"percent_change_7d\": \"1.39\",\n" +
                "      \"price_btc\": \"0.000767\",\n" +
                "      \"market_cap_usd\": \"559170194.47\",\n" +
                "      \"volume24\": 1476431262.9634018,\n" +
                "      \"volume24a\": 1454926160.164054,\n" +
                "      \"csupply\": \"112980348.00\",\n" +
                "      \"tsupply\": \"112980348\",\n" +
                "      \"msupply\": \"210000000\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"33608\",\n" +
                "      \"symbol\": \"HEDG\",\n" +
                "      \"name\": \"HedgeTrade\",\n" +
                "      \"nameid\": \"hedgetrade\",\n" +
                "      \"rank\": 19,\n" +
                "      \"price_usd\": \"1.64\",\n" +
                "      \"percent_change_24h\": \"3.18\",\n" +
                "      \"percent_change_1h\": \"0.38\",\n" +
                "      \"percent_change_7d\": \"3.49\",\n" +
                "      \"price_btc\": \"0.000254\",\n" +
                "      \"market_cap_usd\": \"472814848.89\",\n" +
                "      \"volume24\": 461125.7869014685,\n" +
                "      \"volume24a\": 286287.42166743986,\n" +
                "      \"csupply\": \"288393355.00\",\n" +
                "      \"tsupply\": \"1000000000\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"133\",\n" +
                "      \"symbol\": \"NEO\",\n" +
                "      \"name\": \"Neo\",\n" +
                "      \"nameid\": \"neo\",\n" +
                "      \"rank\": 20,\n" +
                "      \"price_usd\": \"6.61\",\n" +
                "      \"percent_change_24h\": \"4.75\",\n" +
                "      \"percent_change_1h\": \"0.27\",\n" +
                "      \"percent_change_7d\": \"3.76\",\n" +
                "      \"price_btc\": \"0.001024\",\n" +
                "      \"market_cap_usd\": \"466083713.32\",\n" +
                "      \"volume24\": 391534897.6810527,\n" +
                "      \"volume24a\": 338480972.46398324,\n" +
                "      \"csupply\": \"70538831.00\",\n" +
                "      \"tsupply\": \"100000000\",\n" +
                "      \"msupply\": \"100000000\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"33538\",\n" +
                "      \"symbol\": \"MIN\",\n" +
                "      \"name\": \"MINDOL\",\n" +
                "      \"nameid\": \"mindol\",\n" +
                "      \"rank\": 21,\n" +
                "      \"price_usd\": \"2.96\",\n" +
                "      \"percent_change_24h\": \"9.90\",\n" +
                "      \"percent_change_1h\": \"0.85\",\n" +
                "      \"percent_change_7d\": \"0.60\",\n" +
                "      \"price_btc\": \"0.000458\",\n" +
                "      \"market_cap_usd\": \"459332428.90\",\n" +
                "      \"volume24\": 766653.5857525397,\n" +
                "      \"volume24a\": 757698.0767788286,\n" +
                "      \"csupply\": \"155379617.00\",\n" +
                "      \"tsupply\": \"240000000\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"33285\",\n" +
                "      \"symbol\": \"USDC\",\n" +
                "      \"name\": \"USD Coin\",\n" +
                "      \"nameid\": \"usd-coin\",\n" +
                "      \"rank\": 22,\n" +
                "      \"price_usd\": \"0.998318\",\n" +
                "      \"percent_change_24h\": \"-0.21\",\n" +
                "      \"percent_change_1h\": \"0.01\",\n" +
                "      \"percent_change_7d\": \"-0.05\",\n" +
                "      \"price_btc\": \"0.000155\",\n" +
                "      \"market_cap_usd\": \"434300767.02\",\n" +
                "      \"volume24\": 230920677.56329015,\n" +
                "      \"volume24a\": 204986128.20716563,\n" +
                "      \"csupply\": \"435032301.00\",\n" +
                "      \"tsupply\": \"435032301\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"33819\",\n" +
                "      \"symbol\": \"CRO\",\n" +
                "      \"name\": \"Crypto.com Chain\",\n" +
                "      \"nameid\": \"crypto-com-chain\",\n" +
                "      \"rank\": 23,\n" +
                "      \"price_usd\": \"0.044225\",\n" +
                "      \"percent_change_24h\": \"5.50\",\n" +
                "      \"percent_change_1h\": \"2.05\",\n" +
                "      \"percent_change_7d\": \"12.77\",\n" +
                "      \"price_btc\": \"0.000007\",\n" +
                "      \"market_cap_usd\": \"410446487.96\",\n" +
                "      \"volume24\": 5008081.6141557,\n" +
                "      \"volume24a\": 5017601.812655412,\n" +
                "      \"csupply\": \"9280821918.00\",\n" +
                "      \"tsupply\": \"100000000000\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"447\",\n" +
                "      \"symbol\": \"IOTA\",\n" +
                "      \"name\": \"IOTA\",\n" +
                "      \"nameid\": \"iota\",\n" +
                "      \"rank\": 24,\n" +
                "      \"price_usd\": \"0.141691\",\n" +
                "      \"percent_change_24h\": \"5.13\",\n" +
                "      \"percent_change_1h\": \"0.34\",\n" +
                "      \"percent_change_7d\": \"3.45\",\n" +
                "      \"price_btc\": \"0.000022\",\n" +
                "      \"market_cap_usd\": \"393835493.64\",\n" +
                "      \"volume24\": 11200833.676567545,\n" +
                "      \"volume24a\": 9891943.71921568,\n" +
                "      \"csupply\": \"2779530283.00\",\n" +
                "      \"tsupply\": \"2779530283\",\n" +
                "      \"msupply\": \"2779530283\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"33830\",\n" +
                "      \"symbol\": \"ATOM\",\n" +
                "      \"name\": \"Cosmos\",\n" +
                "      \"nameid\": \"cosmos\",\n" +
                "      \"rank\": 25,\n" +
                "      \"price_usd\": \"1.96\",\n" +
                "      \"percent_change_24h\": \"2.98\",\n" +
                "      \"percent_change_1h\": \"0.24\",\n" +
                "      \"percent_change_7d\": \"-5.35\",\n" +
                "      \"price_btc\": \"0.000304\",\n" +
                "      \"market_cap_usd\": \"374507681.52\",\n" +
                "      \"volume24\": 101852225.33547711,\n" +
                "      \"volume24a\": 89302806.74414322,\n" +
                "      \"csupply\": \"190688439.00\",\n" +
                "      \"tsupply\": \"237928231\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"70\",\n" +
                "      \"symbol\": \"NEM\",\n" +
                "      \"name\": \"NEM\",\n" +
                "      \"nameid\": \"nem\",\n" +
                "      \"rank\": 26,\n" +
                "      \"price_usd\": \"0.037338\",\n" +
                "      \"percent_change_24h\": \"1.64\",\n" +
                "      \"percent_change_1h\": \"0.23\",\n" +
                "      \"percent_change_7d\": \"-2.89\",\n" +
                "      \"price_btc\": \"0.000006\",\n" +
                "      \"market_cap_usd\": \"336038306.20\",\n" +
                "      \"volume24\": 29468350.29940792,\n" +
                "      \"volume24a\": 8266379.255961812,\n" +
                "      \"csupply\": \"8999999999.00\",\n" +
                "      \"tsupply\": \"8999999999\",\n" +
                "      \"msupply\": \"8999999999\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"12377\",\n" +
                "      \"symbol\": \"MKR\",\n" +
                "      \"name\": \"Maker\",\n" +
                "      \"nameid\": \"maker\",\n" +
                "      \"rank\": 27,\n" +
                "      \"price_usd\": \"297.81\",\n" +
                "      \"percent_change_24h\": \"1.26\",\n" +
                "      \"percent_change_1h\": \"0.17\",\n" +
                "      \"percent_change_7d\": \"15.96\",\n" +
                "      \"price_btc\": \"0.046142\",\n" +
                "      \"market_cap_usd\": \"297809331.95\",\n" +
                "      \"volume24\": 3836247.8502436066,\n" +
                "      \"volume24a\": 4165128.8869907926,\n" +
                "      \"csupply\": \"1000000.00\",\n" +
                "      \"tsupply\": \"1000000\",\n" +
                "      \"msupply\": \"1000000\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"134\",\n" +
                "      \"symbol\": \"ZEC\",\n" +
                "      \"name\": \"Zcash\",\n" +
                "      \"nameid\": \"zcash\",\n" +
                "      \"rank\": 28,\n" +
                "      \"price_usd\": \"30.65\",\n" +
                "      \"percent_change_24h\": \"5.82\",\n" +
                "      \"percent_change_1h\": \"0.22\",\n" +
                "      \"percent_change_7d\": \"-2.71\",\n" +
                "      \"price_btc\": \"0.004748\",\n" +
                "      \"market_cap_usd\": \"291030902.59\",\n" +
                "      \"volume24\": 358761378.25752014,\n" +
                "      \"volume24a\": 150455273.4103239,\n" +
                "      \"csupply\": \"9496456.00\",\n" +
                "      \"tsupply\": \"9496456\",\n" +
                "      \"msupply\": \"21000000\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"33061\",\n" +
                "      \"symbol\": \"INB\",\n" +
                "      \"name\": \"Insight Chain\",\n" +
                "      \"nameid\": \"insight-chain\",\n" +
                "      \"rank\": 29,\n" +
                "      \"price_usd\": \"0.760400\",\n" +
                "      \"percent_change_24h\": \"5.76\",\n" +
                "      \"percent_change_1h\": \"0.80\",\n" +
                "      \"percent_change_7d\": \"-0.98\",\n" +
                "      \"price_btc\": \"0.000118\",\n" +
                "      \"market_cap_usd\": \"266066004.72\",\n" +
                "      \"volume24\": 17120048.811219476,\n" +
                "      \"volume24a\": 12279881.858774513,\n" +
                "      \"csupply\": \"349902689.00\",\n" +
                "      \"tsupply\": \"10000000000\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"2\",\n" +
                "      \"symbol\": \"DOGE\",\n" +
                "      \"name\": \"Dogecoin\",\n" +
                "      \"nameid\": \"dogecoin\",\n" +
                "      \"rank\": 30,\n" +
                "      \"price_usd\": \"0.001823\",\n" +
                "      \"percent_change_24h\": \"5.15\",\n" +
                "      \"percent_change_1h\": \"0.19\",\n" +
                "      \"percent_change_7d\": \"2.17\",\n" +
                "      \"price_btc\": \"2.82E-7\",\n" +
                "      \"market_cap_usd\": \"225536377.08\",\n" +
                "      \"volume24\": 125294323.40461831,\n" +
                "      \"volume24a\": 124263185.08554396,\n" +
                "      \"csupply\": \"123727126384.00\",\n" +
                "      \"tsupply\": \"123727126384\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"32331\",\n" +
                "      \"symbol\": \"ONT\",\n" +
                "      \"name\": \"Ontology\",\n" +
                "      \"nameid\": \"ontology\",\n" +
                "      \"rank\": 31,\n" +
                "      \"price_usd\": \"0.368096\",\n" +
                "      \"percent_change_24h\": \"2.95\",\n" +
                "      \"percent_change_1h\": \"0.40\",\n" +
                "      \"percent_change_7d\": \"1.21\",\n" +
                "      \"price_btc\": \"0.000057\",\n" +
                "      \"market_cap_usd\": \"196373147.93\",\n" +
                "      \"volume24\": 42217125.96765973,\n" +
                "      \"volume24a\": 40474043.82605815,\n" +
                "      \"csupply\": \"533483170.00\",\n" +
                "      \"tsupply\": \"1000000000\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"32479\",\n" +
                "      \"symbol\": \"TUSD\",\n" +
                "      \"name\": \"TrueUSD\",\n" +
                "      \"nameid\": \"trueusd\",\n" +
                "      \"rank\": 32,\n" +
                "      \"price_usd\": \"0.997727\",\n" +
                "      \"percent_change_24h\": \"0.08\",\n" +
                "      \"percent_change_1h\": \"0.04\",\n" +
                "      \"percent_change_7d\": \"0.03\",\n" +
                "      \"price_btc\": \"0.000155\",\n" +
                "      \"market_cap_usd\": \"195038872.43\",\n" +
                "      \"volume24\": 415672271.6883761,\n" +
                "      \"volume24a\": 313412271.096536,\n" +
                "      \"csupply\": \"195483256.00\",\n" +
                "      \"tsupply\": \"195483256\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"33820\",\n" +
                "      \"symbol\": \"PAX\",\n" +
                "      \"name\": \"Paxos Standard Token\",\n" +
                "      \"nameid\": \"paxos-standard-token\",\n" +
                "      \"rank\": 33,\n" +
                "      \"price_usd\": \"0.998532\",\n" +
                "      \"percent_change_24h\": \"0.25\",\n" +
                "      \"percent_change_1h\": \"0.02\",\n" +
                "      \"percent_change_7d\": \"0.00\",\n" +
                "      \"price_btc\": \"0.000155\",\n" +
                "      \"market_cap_usd\": \"194081661.81\",\n" +
                "      \"volume24\": 446944053.62410784,\n" +
                "      \"volume24a\": 619455420.7768569,\n" +
                "      \"csupply\": \"194366961.00\",\n" +
                "      \"tsupply\": \"194366961\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"184\",\n" +
                "      \"symbol\": \"BAT\",\n" +
                "      \"name\": \"Basic Attention Token\",\n" +
                "      \"nameid\": \"basic-attention-token\",\n" +
                "      \"rank\": 34,\n" +
                "      \"price_usd\": \"0.139569\",\n" +
                "      \"percent_change_24h\": \"4.31\",\n" +
                "      \"percent_change_1h\": \"-0.03\",\n" +
                "      \"percent_change_7d\": \"8.05\",\n" +
                "      \"price_btc\": \"0.000022\",\n" +
                "      \"market_cap_usd\": \"178540824.64\",\n" +
                "      \"volume24\": 59371892.01025062,\n" +
                "      \"volume24a\": 50093027.63924558,\n" +
                "      \"csupply\": \"1279225522.00\",\n" +
                "      \"tsupply\": \"1500000000\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"32351\",\n" +
                "      \"symbol\": \"HT\",\n" +
                "      \"name\": \"Huobi Token\",\n" +
                "      \"nameid\": \"huobi-token\",\n" +
                "      \"rank\": 35,\n" +
                "      \"price_usd\": \"3.28\",\n" +
                "      \"percent_change_24h\": \"5.38\",\n" +
                "      \"percent_change_1h\": \"0.19\",\n" +
                "      \"percent_change_7d\": \"0.35\",\n" +
                "      \"price_btc\": \"0.000508\",\n" +
                "      \"market_cap_usd\": \"163923222.86\",\n" +
                "      \"volume24\": 119695933.20629045,\n" +
                "      \"volume24a\": 110087946.21911317,\n" +
                "      \"csupply\": \"50000200.00\",\n" +
                "      \"tsupply\": \"500000000\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"2741\",\n" +
                "      \"symbol\": \"VET\",\n" +
                "      \"name\": \"VeChain\",\n" +
                "      \"nameid\": \"vechain\",\n" +
                "      \"rank\": 36,\n" +
                "      \"price_usd\": \"0.002952\",\n" +
                "      \"percent_change_24h\": \"3.85\",\n" +
                "      \"percent_change_1h\": \"0.56\",\n" +
                "      \"percent_change_7d\": \"4.90\",\n" +
                "      \"price_btc\": \"4.57E-7\",\n" +
                "      \"market_cap_usd\": \"163714797.71\",\n" +
                "      \"volume24\": 81256253.47891688,\n" +
                "      \"volume24a\": 66544871.783197895,\n" +
                "      \"csupply\": \"55454734800.00\",\n" +
                "      \"tsupply\": \"86712634466\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"99\",\n" +
                "      \"symbol\": \"DCR\",\n" +
                "      \"name\": \"Decred\",\n" +
                "      \"nameid\": \"decred\",\n" +
                "      \"rank\": 37,\n" +
                "      \"price_usd\": \"11.26\",\n" +
                "      \"percent_change_24h\": \"7.99\",\n" +
                "      \"percent_change_1h\": \"-0.04\",\n" +
                "      \"percent_change_7d\": \"-0.03\",\n" +
                "      \"price_btc\": \"0.001745\",\n" +
                "      \"market_cap_usd\": \"126747553.86\",\n" +
                "      \"volume24\": 65033460.342110015,\n" +
                "      \"volume24a\": 69975373.09303191,\n" +
                "      \"csupply\": \"11255663.00\",\n" +
                "      \"tsupply\": \"11255663\",\n" +
                "      \"msupply\": \"21000000\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"285\",\n" +
                "      \"symbol\": \"BTG\",\n" +
                "      \"name\": \"Bitcoin Gold\",\n" +
                "      \"nameid\": \"bitcoingold\",\n" +
                "      \"rank\": 38,\n" +
                "      \"price_usd\": \"7.27\",\n" +
                "      \"percent_change_24h\": \"6.48\",\n" +
                "      \"percent_change_1h\": \"-0.02\",\n" +
                "      \"percent_change_7d\": \"-1.66\",\n" +
                "      \"price_btc\": \"0.001126\",\n" +
                "      \"market_cap_usd\": \"125352714.31\",\n" +
                "      \"volume24\": 17670648.542690042,\n" +
                "      \"volume24a\": 15953746.20242821,\n" +
                "      \"csupply\": \"17248611.00\",\n" +
                "      \"tsupply\": \"17348611\",\n" +
                "      \"msupply\": \"21000000\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"108\",\n" +
                "      \"symbol\": \"LSK\",\n" +
                "      \"name\": \"Lisk\",\n" +
                "      \"nameid\": \"lisk\",\n" +
                "      \"rank\": 39,\n" +
                "      \"price_usd\": \"0.970054\",\n" +
                "      \"percent_change_24h\": \"4.31\",\n" +
                "      \"percent_change_1h\": \"0.13\",\n" +
                "      \"percent_change_7d\": \"-4.18\",\n" +
                "      \"price_btc\": \"0.000150\",\n" +
                "      \"market_cap_usd\": \"116031298.38\",\n" +
                "      \"volume24\": 2637384.2154397746,\n" +
                "      \"volume24a\": 2473435.703484393,\n" +
                "      \"csupply\": \"119613215.00\",\n" +
                "      \"tsupply\": \"125643660\",\n" +
                "      \"msupply\": \"159918400\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"237\",\n" +
                "      \"symbol\": \"QTUM\",\n" +
                "      \"name\": \"Qtum\",\n" +
                "      \"nameid\": \"qtum\",\n" +
                "      \"rank\": 40,\n" +
                "      \"price_usd\": \"1.20\",\n" +
                "      \"percent_change_24h\": \"2.69\",\n" +
                "      \"percent_change_1h\": \"0.21\",\n" +
                "      \"percent_change_7d\": \"-0.46\",\n" +
                "      \"price_btc\": \"0.000186\",\n" +
                "      \"market_cap_usd\": \"115169661.80\",\n" +
                "      \"volume24\": 336852699.10505044,\n" +
                "      \"volume24a\": 293486846.2696874,\n" +
                "      \"csupply\": \"95969372.00\",\n" +
                "      \"tsupply\": \"100909224\",\n" +
                "      \"msupply\": \"100909224\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"129\",\n" +
                "      \"symbol\": \"REP\",\n" +
                "      \"name\": \"Augur\",\n" +
                "      \"nameid\": \"augur\",\n" +
                "      \"rank\": 41,\n" +
                "      \"price_usd\": \"10.26\",\n" +
                "      \"percent_change_24h\": \"5.72\",\n" +
                "      \"percent_change_1h\": \"1.05\",\n" +
                "      \"percent_change_7d\": \"24.58\",\n" +
                "      \"price_btc\": \"0.001589\",\n" +
                "      \"market_cap_usd\": \"112837966.10\",\n" +
                "      \"volume24\": 10310728.79275543,\n" +
                "      \"volume24a\": 10033251.143177396,\n" +
                "      \"csupply\": \"11000000.00\",\n" +
                "      \"tsupply\": \"11000000\",\n" +
                "      \"msupply\": \"11000000\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"3708\",\n" +
                "      \"symbol\": \"ICX\",\n" +
                "      \"name\": \"ICON\",\n" +
                "      \"nameid\": \"icon\",\n" +
                "      \"rank\": 42,\n" +
                "      \"price_usd\": \"0.208830\",\n" +
                "      \"percent_change_24h\": \"13.39\",\n" +
                "      \"percent_change_1h\": \"0.00\",\n" +
                "      \"percent_change_7d\": \"7.64\",\n" +
                "      \"price_btc\": \"0.000032\",\n" +
                "      \"market_cap_usd\": \"102421281.11\",\n" +
                "      \"volume24\": 23710062.559112974,\n" +
                "      \"volume24a\": 12685110.101983206,\n" +
                "      \"csupply\": \"490453303.00\",\n" +
                "      \"tsupply\": \"800460000\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"33821\",\n" +
                "      \"symbol\": \"ABBC\",\n" +
                "      \"name\": \"ABBC Coin\",\n" +
                "      \"nameid\": \"abbc-coin\",\n" +
                "      \"rank\": 43,\n" +
                "      \"price_usd\": \"0.091425\",\n" +
                "      \"percent_change_24h\": \"3.44\",\n" +
                "      \"percent_change_1h\": \"-0.17\",\n" +
                "      \"percent_change_7d\": \"-2.93\",\n" +
                "      \"price_btc\": \"0.000014\",\n" +
                "      \"market_cap_usd\": \"91788577.47\",\n" +
                "      \"volume24\": 20431021.026234824,\n" +
                "      \"volume24a\": 15036040.029980706,\n" +
                "      \"csupply\": \"1003981087.00\",\n" +
                "      \"tsupply\": \"1003981087\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"32073\",\n" +
                "      \"symbol\": \"BCD\",\n" +
                "      \"name\": \"Bitcoin Diamond\",\n" +
                "      \"nameid\": \"bitcoin-diamond\",\n" +
                "      \"rank\": 44,\n" +
                "      \"price_usd\": \"0.490752\",\n" +
                "      \"percent_change_24h\": \"9.81\",\n" +
                "      \"percent_change_1h\": \"0.08\",\n" +
                "      \"percent_change_7d\": \"1.09\",\n" +
                "      \"price_btc\": \"0.000076\",\n" +
                "      \"market_cap_usd\": \"91521796.88\",\n" +
                "      \"volume24\": 6100493.224168646,\n" +
                "      \"volume24a\": 5268976.852036506,\n" +
                "      \"csupply\": \"186492898.00\",\n" +
                "      \"tsupply\": \"186492898\",\n" +
                "      \"msupply\": \"210000000\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"2729\",\n" +
                "      \"symbol\": \"ZRX\",\n" +
                "      \"name\": \"0x\",\n" +
                "      \"nameid\": \"0x\",\n" +
                "      \"rank\": 45,\n" +
                "      \"price_usd\": \"0.151422\",\n" +
                "      \"percent_change_24h\": \"2.66\",\n" +
                "      \"percent_change_1h\": \"0.48\",\n" +
                "      \"percent_change_7d\": \"1.79\",\n" +
                "      \"price_btc\": \"0.000023\",\n" +
                "      \"market_cap_usd\": \"90924976.83\",\n" +
                "      \"volume24\": 11761225.522733338,\n" +
                "      \"volume24a\": 10714804.837247089,\n" +
                "      \"csupply\": \"600475853.00\",\n" +
                "      \"tsupply\": \"1000000000\",\n" +
                "      \"msupply\": \"1000000000\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"33531\",\n" +
                "      \"symbol\": \"OKB\",\n" +
                "      \"name\": \"OKB\",\n" +
                "      \"nameid\": \"okb\",\n" +
                "      \"rank\": 46,\n" +
                "      \"price_usd\": \"4.28\",\n" +
                "      \"percent_change_24h\": \"6.44\",\n" +
                "      \"percent_change_1h\": \"0.80\",\n" +
                "      \"percent_change_7d\": \"2.33\",\n" +
                "      \"price_btc\": \"0.000664\",\n" +
                "      \"market_cap_usd\": \"85671920.99\",\n" +
                "      \"volume24\": 233068777.94044697,\n" +
                "      \"volume24a\": 215060618.14720425,\n" +
                "      \"csupply\": \"20000000.00\",\n" +
                "      \"tsupply\": \"300000000\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"2750\",\n" +
                "      \"symbol\": \"KCS\",\n" +
                "      \"name\": \"KuCoin Shares\",\n" +
                "      \"nameid\": \"kucoin-shares\",\n" +
                "      \"rank\": 47,\n" +
                "      \"price_usd\": \"0.957761\",\n" +
                "      \"percent_change_24h\": \"6.68\",\n" +
                "      \"percent_change_1h\": \"0.07\",\n" +
                "      \"percent_change_7d\": \"-15.99\",\n" +
                "      \"price_btc\": \"0.000148\",\n" +
                "      \"market_cap_usd\": \"84997184.67\",\n" +
                "      \"volume24\": 6490604.854183959,\n" +
                "      \"volume24a\": 4150107.5052189855,\n" +
                "      \"csupply\": \"88745681.00\",\n" +
                "      \"tsupply\": \"180730576\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"113\",\n" +
                "      \"symbol\": \"WAVES\",\n" +
                "      \"name\": \"Waves\",\n" +
                "      \"nameid\": \"waves\",\n" +
                "      \"rank\": 48,\n" +
                "      \"price_usd\": \"0.830527\",\n" +
                "      \"percent_change_24h\": \"5.19\",\n" +
                "      \"percent_change_1h\": \"0.16\",\n" +
                "      \"percent_change_7d\": \"-8.18\",\n" +
                "      \"price_btc\": \"0.000129\",\n" +
                "      \"market_cap_usd\": \"83052703.22\",\n" +
                "      \"volume24\": 41399354.30597341,\n" +
                "      \"volume24a\": 35381834.418225326,\n" +
                "      \"csupply\": \"100000000.00\",\n" +
                "      \"tsupply\": \"100000000\",\n" +
                "      \"msupply\": \"100000000\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"32417\",\n" +
                "      \"symbol\": \"DAI\",\n" +
                "      \"name\": \"Dai\",\n" +
                "      \"nameid\": \"dai\",\n" +
                "      \"rank\": 49,\n" +
                "      \"price_usd\": \"1.02\",\n" +
                "      \"percent_change_24h\": \"-0.70\",\n" +
                "      \"percent_change_1h\": \"0.15\",\n" +
                "      \"percent_change_7d\": \"-1.02\",\n" +
                "      \"price_btc\": \"0.000158\",\n" +
                "      \"market_cap_usd\": \"79830523.54\",\n" +
                "      \"volume24\": 10741981.554131776,\n" +
                "      \"volume24a\": 9222474.626170952,\n" +
                "      \"csupply\": \"78262606.00\",\n" +
                "      \"tsupply\": \"78262606\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"22\",\n" +
                "      \"symbol\": \"MONA\",\n" +
                "      \"name\": \"MonaCoin\",\n" +
                "      \"nameid\": \"monacoin\",\n" +
                "      \"rank\": 50,\n" +
                "      \"price_usd\": \"1.20\",\n" +
                "      \"percent_change_24h\": \"5.39\",\n" +
                "      \"percent_change_1h\": \"-0.04\",\n" +
                "      \"percent_change_7d\": \"-1.80\",\n" +
                "      \"price_btc\": \"0.000186\",\n" +
                "      \"market_cap_usd\": \"78800220.35\",\n" +
                "      \"volume24\": 4338528.960888549,\n" +
                "      \"volume24a\": 3253389.5778062893,\n" +
                "      \"csupply\": \"65729675.00\",\n" +
                "      \"tsupply\": \"65729675\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"211\",\n" +
                "      \"symbol\": \"MCO\",\n" +
                "      \"name\": \"Crypto.com\",\n" +
                "      \"nameid\": \"monaco\",\n" +
                "      \"rank\": 51,\n" +
                "      \"price_usd\": \"4.81\",\n" +
                "      \"percent_change_24h\": \"9.93\",\n" +
                "      \"percent_change_1h\": \"0.51\",\n" +
                "      \"percent_change_7d\": \"7.77\",\n" +
                "      \"price_btc\": \"0.000746\",\n" +
                "      \"market_cap_usd\": \"76008183.31\",\n" +
                "      \"volume24\": 23298194.696218904,\n" +
                "      \"volume24a\": 29486804.03557067,\n" +
                "      \"csupply\": \"15793831.00\",\n" +
                "      \"tsupply\": \"31587682\",\n" +
                "      \"msupply\": \"31587682.3632061\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"33723\",\n" +
                "      \"symbol\": \"SNX\",\n" +
                "      \"name\": \"Synthetix Network Token\",\n" +
                "      \"nameid\": \"synthetix-network-token\",\n" +
                "      \"rank\": 52,\n" +
                "      \"price_usd\": \"0.600009\",\n" +
                "      \"percent_change_24h\": \"6.48\",\n" +
                "      \"percent_change_1h\": \"-0.26\",\n" +
                "      \"percent_change_7d\": \"29.05\",\n" +
                "      \"price_btc\": \"0.000093\",\n" +
                "      \"market_cap_usd\": \"75576425.92\",\n" +
                "      \"volume24\": 1095538.576921287,\n" +
                "      \"volume24a\": 705011.5087199009,\n" +
                "      \"csupply\": \"125958830.00\",\n" +
                "      \"tsupply\": \"125958830\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"2515\",\n" +
                "      \"symbol\": \"KNC\",\n" +
                "      \"name\": \"Kyber Network\",\n" +
                "      \"nameid\": \"kyber-network\",\n" +
                "      \"rank\": 53,\n" +
                "      \"price_usd\": \"0.439225\",\n" +
                "      \"percent_change_24h\": \"2.58\",\n" +
                "      \"percent_change_1h\": \"0.05\",\n" +
                "      \"percent_change_7d\": \"-1.15\",\n" +
                "      \"price_btc\": \"0.000068\",\n" +
                "      \"market_cap_usd\": \"73730345.66\",\n" +
                "      \"volume24\": 39016307.962784454,\n" +
                "      \"volume24a\": 40319641.00861912,\n" +
                "      \"csupply\": \"167864614.00\",\n" +
                "      \"tsupply\": \"215625349\",\n" +
                "      \"msupply\": \"226000000\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"2581\",\n" +
                "      \"symbol\": \"ENJ\",\n" +
                "      \"name\": \"Enjin Coin\",\n" +
                "      \"nameid\": \"enjin-coin\",\n" +
                "      \"rank\": 54,\n" +
                "      \"price_usd\": \"0.092690\",\n" +
                "      \"percent_change_24h\": \"9.07\",\n" +
                "      \"percent_change_1h\": \"-1.39\",\n" +
                "      \"percent_change_7d\": \"29.53\",\n" +
                "      \"price_btc\": \"0.000014\",\n" +
                "      \"market_cap_usd\": \"71953644.91\",\n" +
                "      \"volume24\": 7901844.985064777,\n" +
                "      \"volume24a\": 5519908.550346155,\n" +
                "      \"csupply\": \"776278713.00\",\n" +
                "      \"tsupply\": \"1000000000\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"232\",\n" +
                "      \"symbol\": \"OMG\",\n" +
                "      \"name\": \"OmiseGO\",\n" +
                "      \"nameid\": \"omisego\",\n" +
                "      \"rank\": 55,\n" +
                "      \"price_usd\": \"0.512614\",\n" +
                "      \"percent_change_24h\": \"6.80\",\n" +
                "      \"percent_change_1h\": \"0.18\",\n" +
                "      \"percent_change_7d\": \"0.88\",\n" +
                "      \"price_btc\": \"0.000079\",\n" +
                "      \"market_cap_usd\": \"71891711.29\",\n" +
                "      \"volume24\": 108746553.38548917,\n" +
                "      \"volume24a\": 126502704.11185701,\n" +
                "      \"csupply\": \"140245398.00\",\n" +
                "      \"tsupply\": \"140245398\",\n" +
                "      \"msupply\": \"140245398\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"32386\",\n" +
                "      \"symbol\": \"RVN\",\n" +
                "      \"name\": \"Ravencoin\",\n" +
                "      \"nameid\": \"ravencoin\",\n" +
                "      \"rank\": 56,\n" +
                "      \"price_usd\": \"0.014789\",\n" +
                "      \"percent_change_24h\": \"4.90\",\n" +
                "      \"percent_change_1h\": \"-0.12\",\n" +
                "      \"percent_change_7d\": \"4.33\",\n" +
                "      \"price_btc\": \"0.000002\",\n" +
                "      \"market_cap_usd\": \"63243435.47\",\n" +
                "      \"volume24\": 8531531.3816872,\n" +
                "      \"volume24a\": 6595817.326920285,\n" +
                "      \"csupply\": \"4276480000.00\",\n" +
                "      \"tsupply\": \"4276480000\",\n" +
                "      \"msupply\": \"21000000000\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"207\",\n" +
                "      \"symbol\": \"SNT\",\n" +
                "      \"name\": \"Status Network Token\",\n" +
                "      \"nameid\": \"status\",\n" +
                "      \"rank\": 57,\n" +
                "      \"price_usd\": \"0.018187\",\n" +
                "      \"percent_change_24h\": \"-2.42\",\n" +
                "      \"percent_change_1h\": \"-0.01\",\n" +
                "      \"percent_change_7d\": \"19.29\",\n" +
                "      \"price_btc\": \"0.000003\",\n" +
                "      \"market_cap_usd\": \"63116598.29\",\n" +
                "      \"volume24\": 40562827.160619855,\n" +
                "      \"volume24a\": 55674586.753741816,\n" +
                "      \"csupply\": \"3470483788.00\",\n" +
                "      \"tsupply\": \"6804870174\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"2835\",\n" +
                "      \"symbol\": \"NANO\",\n" +
                "      \"name\": \"Nano\",\n" +
                "      \"nameid\": \"nano\",\n" +
                "      \"rank\": 58,\n" +
                "      \"price_usd\": \"0.463374\",\n" +
                "      \"percent_change_24h\": \"4.02\",\n" +
                "      \"percent_change_1h\": \"0.29\",\n" +
                "      \"percent_change_7d\": \"7.02\",\n" +
                "      \"price_btc\": \"0.000072\",\n" +
                "      \"market_cap_usd\": \"61743813.78\",\n" +
                "      \"volume24\": 2388515.7034607977,\n" +
                "      \"volume24a\": 1886316.558222324,\n" +
                "      \"csupply\": \"133248297.00\",\n" +
                "      \"tsupply\": \"133248297\",\n" +
                "      \"msupply\": \"133248297\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"32604\",\n" +
                "      \"symbol\": \"NEXO\",\n" +
                "      \"name\": \"Nexo\",\n" +
                "      \"nameid\": \"nexo\",\n" +
                "      \"rank\": 59,\n" +
                "      \"price_usd\": \"0.107268\",\n" +
                "      \"percent_change_24h\": \"5.21\",\n" +
                "      \"percent_change_1h\": \"0.58\",\n" +
                "      \"percent_change_7d\": \"4.49\",\n" +
                "      \"price_btc\": \"0.000017\",\n" +
                "      \"market_cap_usd\": \"60070235.81\",\n" +
                "      \"volume24\": 9802498.267094547,\n" +
                "      \"volume24a\": 9783570.042189633,\n" +
                "      \"csupply\": \"560000011.00\",\n" +
                "      \"tsupply\": \"1000000000\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"33071\",\n" +
                "      \"symbol\": \"DX\",\n" +
                "      \"name\": \"DxChain Token\",\n" +
                "      \"nameid\": \"dxchain-token\",\n" +
                "      \"rank\": 60,\n" +
                "      \"price_usd\": \"0.001278\",\n" +
                "      \"percent_change_24h\": \"7.74\",\n" +
                "      \"percent_change_1h\": \"-0.20\",\n" +
                "      \"percent_change_7d\": \"2.88\",\n" +
                "      \"price_btc\": \"1.98E-7\",\n" +
                "      \"market_cap_usd\": \"59113528.48\",\n" +
                "      \"volume24\": 1436525.471456792,\n" +
                "      \"volume24a\": 1284538.3185219963,\n" +
                "      \"csupply\": \"46250000000.00\",\n" +
                "      \"tsupply\": \"100000000000\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"43\",\n" +
                "      \"symbol\": \"DGB\",\n" +
                "      \"name\": \"Digibyte\",\n" +
                "      \"nameid\": \"digibyte\",\n" +
                "      \"rank\": 61,\n" +
                "      \"price_usd\": \"0.004472\",\n" +
                "      \"percent_change_24h\": \"6.05\",\n" +
                "      \"percent_change_1h\": \"1.12\",\n" +
                "      \"percent_change_7d\": \"32.30\",\n" +
                "      \"price_btc\": \"6.93E-7\",\n" +
                "      \"market_cap_usd\": \"57919548.14\",\n" +
                "      \"volume24\": 900927.9274728488,\n" +
                "      \"volume24a\": 779466.9045117848,\n" +
                "      \"csupply\": \"12950710845.00\",\n" +
                "      \"tsupply\": \"12950710845\",\n" +
                "      \"msupply\": \"21000000000\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"2482\",\n" +
                "      \"symbol\": \"BTM\",\n" +
                "      \"name\": \"Bytom\",\n" +
                "      \"nameid\": \"bytom\",\n" +
                "      \"rank\": 62,\n" +
                "      \"price_usd\": \"0.057384\",\n" +
                "      \"percent_change_24h\": \"-0.08\",\n" +
                "      \"percent_change_1h\": \"0.63\",\n" +
                "      \"percent_change_7d\": \"6.26\",\n" +
                "      \"price_btc\": \"0.000009\",\n" +
                "      \"market_cap_usd\": \"57527118.74\",\n" +
                "      \"volume24\": 152500756.49996197,\n" +
                "      \"volume24a\": 112802647.72399184,\n" +
                "      \"csupply\": \"1002499275.00\",\n" +
                "      \"tsupply\": \"1407000000\",\n" +
                "      \"msupply\": \"1407000000\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"183\",\n" +
                "      \"symbol\": \"SC\",\n" +
                "      \"name\": \"Siacoin\",\n" +
                "      \"nameid\": \"siacoin\",\n" +
                "      \"rank\": 63,\n" +
                "      \"price_usd\": \"0.001260\",\n" +
                "      \"percent_change_24h\": \"3.71\",\n" +
                "      \"percent_change_1h\": \"0.68\",\n" +
                "      \"percent_change_7d\": \"-2.50\",\n" +
                "      \"price_btc\": \"1.95E-7\",\n" +
                "      \"market_cap_usd\": \"52682667.76\",\n" +
                "      \"volume24\": 2388220.740453169,\n" +
                "      \"volume24a\": 2564465.1114990697,\n" +
                "      \"csupply\": \"41817047634.00\",\n" +
                "      \"tsupply\": \"41817047634\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"32360\",\n" +
                "      \"symbol\": \"THETA\",\n" +
                "      \"name\": \"Theta Token\",\n" +
                "      \"nameid\": \"theta-token\",\n" +
                "      \"rank\": 64,\n" +
                "      \"price_usd\": \"0.072764\",\n" +
                "      \"percent_change_24h\": \"8.54\",\n" +
                "      \"percent_change_1h\": \"0.43\",\n" +
                "      \"percent_change_7d\": \"7.35\",\n" +
                "      \"price_btc\": \"0.000011\",\n" +
                "      \"market_cap_usd\": \"51408112.88\",\n" +
                "      \"volume24\": 2030204.2759182877,\n" +
                "      \"volume24a\": 1643132.3723694822,\n" +
                "      \"csupply\": \"706502689.00\",\n" +
                "      \"tsupply\": \"1000000000\",\n" +
                "      \"msupply\": null\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"111\",\n" +
                "      \"symbol\": \"DGD\",\n" +
                "      \"name\": \"DigixDAO\",\n" +
                "      \"nameid\": \"digixdao\",\n" +
                "      \"rank\": 65,\n" +
                "      \"price_usd\": \"25.58\",\n" +
                "      \"percent_change_24h\": \"5.62\",\n" +
                "      \"percent_change_1h\": \"0.15\",\n" +
                "      \"percent_change_7d\": \"3.48\",\n" +
                "      \"price_btc\": \"0.003964\",\n" +
                "      \"market_cap_usd\": \"51165639.49\",\n" +
                "      \"volume24\": 943561.9619515446,\n" +
                "      \"volume24a\": 864526.4844985588,\n" +
                "      \"csupply\": \"2000000.00\",\n" +
                "      \"tsupply\": \"2000000\",\n" +
                "      \"msupply\": \"2000000\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"106\",\n" +
                "      \"symbol\": \"STEEM\",\n" +
                "      \"name\": \"STEEM\",\n" +
                "      \"nameid\": \"steem\",\n" +
                "      \"rank\": 66,\n" +
                "      \"price_usd\": \"0.141484\",\n" +
                "      \"percent_change_24h\": \"0.75\",\n" +
                "      \"percent_change_1h\": \"0.11\",\n" +
                "      \"percent_change_7d\": \"-14.90\",\n" +
                "      \"price_btc\": \"0.000022\",\n" +
                "      \"market_cap_usd\": \"48437828.08\",\n" +
                "      \"volume24\": 1516637.2386758102,\n" +
                "      \"volume24a\": 1508801.2823595253,\n" +
                "      \"csupply\": \"342356149.00\",\n" +
                "      \"tsupply\": \"342356149\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"33391\",\n" +
                "      \"symbol\": \"BTT\",\n" +
                "      \"name\": \"BitTorrent\",\n" +
                "      \"nameid\": \"bittorrent\",\n" +
                "      \"rank\": 67,\n" +
                "      \"price_usd\": \"0.000219\",\n" +
                "      \"percent_change_24h\": \"5.27\",\n" +
                "      \"percent_change_1h\": \"-0.45\",\n" +
                "      \"percent_change_7d\": \"1.52\",\n" +
                "      \"price_btc\": \"3.40E-8\",\n" +
                "      \"market_cap_usd\": \"46547328.24\",\n" +
                "      \"volume24\": 4326466.253240117,\n" +
                "      \"volume24a\": 3677081.390427456,\n" +
                "      \"csupply\": \"212116500000.00\",\n" +
                "      \"tsupply\": \"990000000000\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"33085\",\n" +
                "      \"symbol\": \"QNT\",\n" +
                "      \"name\": \"Quant\",\n" +
                "      \"nameid\": \"quant\",\n" +
                "      \"rank\": 68,\n" +
                "      \"price_usd\": \"3.80\",\n" +
                "      \"percent_change_24h\": \"15.02\",\n" +
                "      \"percent_change_1h\": \"-1.93\",\n" +
                "      \"percent_change_7d\": \"73.02\",\n" +
                "      \"price_btc\": \"0.000589\",\n" +
                "      \"market_cap_usd\": \"45926481.73\",\n" +
                "      \"volume24\": 3149648.9427627283,\n" +
                "      \"volume24a\": 2808665.761041458,\n" +
                "      \"csupply\": \"12072738.00\",\n" +
                "      \"tsupply\": \"45467000\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"54\",\n" +
                "      \"symbol\": \"BTS\",\n" +
                "      \"name\": \"BitShares\",\n" +
                "      \"nameid\": \"bitshares\",\n" +
                "      \"rank\": 69,\n" +
                "      \"price_usd\": \"0.016100\",\n" +
                "      \"percent_change_24h\": \"4.08\",\n" +
                "      \"percent_change_1h\": \"0.25\",\n" +
                "      \"percent_change_7d\": \"-3.88\",\n" +
                "      \"price_btc\": \"0.000002\",\n" +
                "      \"market_cap_usd\": \"44129311.27\",\n" +
                "      \"volume24\": 2992284.7216162374,\n" +
                "      \"volume24a\": 5394305.804138768,\n" +
                "      \"csupply\": \"2740910000.00\",\n" +
                "      \"tsupply\": \"2740910000\",\n" +
                "      \"msupply\": \"3600570502\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"32686\",\n" +
                "      \"symbol\": \"HOT\",\n" +
                "      \"name\": \"Holo\",\n" +
                "      \"nameid\": \"holo\",\n" +
                "      \"rank\": 70,\n" +
                "      \"price_usd\": \"0.000329\",\n" +
                "      \"percent_change_24h\": \"3.58\",\n" +
                "      \"percent_change_1h\": \"-0.99\",\n" +
                "      \"percent_change_7d\": \"3.96\",\n" +
                "      \"price_btc\": \"5.10E-8\",\n" +
                "      \"market_cap_usd\": \"43835447.73\",\n" +
                "      \"volume24\": 3055155.7405272108,\n" +
                "      \"volume24a\": 3036479.6870466466,\n" +
                "      \"csupply\": \"133214575156.00\",\n" +
                "      \"tsupply\": \"177619433541\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"33228\",\n" +
                "      \"symbol\": \"HC\",\n" +
                "      \"name\": \"HyperCash\",\n" +
                "      \"nameid\": \"hypercash\",\n" +
                "      \"rank\": 71,\n" +
                "      \"price_usd\": \"0.981966\",\n" +
                "      \"percent_change_24h\": \"7.08\",\n" +
                "      \"percent_change_1h\": \"0.93\",\n" +
                "      \"percent_change_7d\": \"0.41\",\n" +
                "      \"price_btc\": \"0.000152\",\n" +
                "      \"market_cap_usd\": \"42744767.66\",\n" +
                "      \"volume24\": 735059.8874595849,\n" +
                "      \"volume24a\": 487495.7968373007,\n" +
                "      \"csupply\": \"43529781.00\",\n" +
                "      \"tsupply\": \"43529781\",\n" +
                "      \"msupply\": \"84000000\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"186\",\n" +
                "      \"symbol\": \"ZEN\",\n" +
                "      \"name\": \"Horizen\",\n" +
                "      \"nameid\": \"zencash\",\n" +
                "      \"rank\": 72,\n" +
                "      \"price_usd\": \"5.73\",\n" +
                "      \"percent_change_24h\": \"3.48\",\n" +
                "      \"percent_change_1h\": \"0.40\",\n" +
                "      \"percent_change_7d\": \"8.26\",\n" +
                "      \"price_btc\": \"0.000888\",\n" +
                "      \"market_cap_usd\": \"41195503.21\",\n" +
                "      \"volume24\": 1575387.3225299618,\n" +
                "      \"volume24a\": 1798947.4938717019,\n" +
                "      \"csupply\": \"7185725.00\",\n" +
                "      \"tsupply\": \"7185725\",\n" +
                "      \"msupply\": \"21000000\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"139\",\n" +
                "      \"symbol\": \"KMD\",\n" +
                "      \"name\": \"Komodo\",\n" +
                "      \"nameid\": \"komodo\",\n" +
                "      \"rank\": 73,\n" +
                "      \"price_usd\": \"0.354136\",\n" +
                "      \"percent_change_24h\": \"4.48\",\n" +
                "      \"percent_change_1h\": \"-0.79\",\n" +
                "      \"percent_change_7d\": \"-1.35\",\n" +
                "      \"price_btc\": \"0.000055\",\n" +
                "      \"market_cap_usd\": \"40953183.80\",\n" +
                "      \"volume24\": 1464234.859763976,\n" +
                "      \"volume24a\": 1776725.9793005914,\n" +
                "      \"csupply\": \"115642437.00\",\n" +
                "      \"tsupply\": \"115642437\",\n" +
                "      \"msupply\": \"200000000\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"34406\",\n" +
                "      \"symbol\": \"ALGO\",\n" +
                "      \"name\": \"Algorand\",\n" +
                "      \"nameid\": \"algorand\",\n" +
                "      \"rank\": 74,\n" +
                "      \"price_usd\": \"0.154780\",\n" +
                "      \"percent_change_24h\": \"5.24\",\n" +
                "      \"percent_change_1h\": \"-0.01\",\n" +
                "      \"percent_change_7d\": \"0.09\",\n" +
                "      \"price_btc\": \"0.000024\",\n" +
                "      \"market_cap_usd\": \"40127711.09\",\n" +
                "      \"volume24\": 37759689.153416745,\n" +
                "      \"volume24a\": 32876635.640288547,\n" +
                "      \"csupply\": \"259256762.00\",\n" +
                "      \"tsupply\": \"2588969743\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"102\",\n" +
                "      \"symbol\": \"XVG\",\n" +
                "      \"name\": \"Verge\",\n" +
                "      \"nameid\": \"verge\",\n" +
                "      \"rank\": 75,\n" +
                "      \"price_usd\": \"0.002477\",\n" +
                "      \"percent_change_24h\": \"1.75\",\n" +
                "      \"percent_change_1h\": \"0.41\",\n" +
                "      \"percent_change_7d\": \"0.94\",\n" +
                "      \"price_btc\": \"3.84E-7\",\n" +
                "      \"market_cap_usd\": \"39380598.63\",\n" +
                "      \"volume24\": 1158489.514523673,\n" +
                "      \"volume24a\": 1345457.7485054682,\n" +
                "      \"csupply\": \"15900663549.00\",\n" +
                "      \"tsupply\": \"15900663549\",\n" +
                "      \"msupply\": \"16555000000\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"33535\",\n" +
                "      \"symbol\": \"VSYS\",\n" +
                "      \"name\": \"V Systems\",\n" +
                "      \"nameid\": \"v-systems\",\n" +
                "      \"rank\": 76,\n" +
                "      \"price_usd\": \"0.021936\",\n" +
                "      \"percent_change_24h\": \"5.14\",\n" +
                "      \"percent_change_1h\": \"0.04\",\n" +
                "      \"percent_change_7d\": \"-8.88\",\n" +
                "      \"price_btc\": \"0.000003\",\n" +
                "      \"market_cap_usd\": \"39239774.00\",\n" +
                "      \"volume24\": 4248783.458336264,\n" +
                "      \"volume24a\": 3694254.4512948934,\n" +
                "      \"csupply\": \"1788818695.00\",\n" +
                "      \"tsupply\": \"5217805440\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"33529\",\n" +
                "      \"symbol\": \"ZB\",\n" +
                "      \"name\": \"ZB\",\n" +
                "      \"nameid\": \"zb\",\n" +
                "      \"rank\": 77,\n" +
                "      \"price_usd\": \"0.222648\",\n" +
                "      \"percent_change_24h\": \"2.47\",\n" +
                "      \"percent_change_1h\": \"-0.06\",\n" +
                "      \"percent_change_7d\": \"-1.70\",\n" +
                "      \"price_btc\": \"0.000034\",\n" +
                "      \"market_cap_usd\": \"36335818.77\",\n" +
                "      \"volume24\": 33374252.192715604,\n" +
                "      \"volume24a\": 37147157.406656265,\n" +
                "      \"csupply\": \"163198810.00\",\n" +
                "      \"tsupply\": \"2100000000\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"32229\",\n" +
                "      \"symbol\": \"IOST\",\n" +
                "      \"name\": \"IOStoken\",\n" +
                "      \"nameid\": \"iostoken\",\n" +
                "      \"rank\": 78,\n" +
                "      \"price_usd\": \"0.002978\",\n" +
                "      \"percent_change_24h\": \"4.16\",\n" +
                "      \"percent_change_1h\": \"-0.09\",\n" +
                "      \"percent_change_7d\": \"-5.39\",\n" +
                "      \"price_btc\": \"4.61E-7\",\n" +
                "      \"market_cap_usd\": \"35773164.17\",\n" +
                "      \"volume24\": 22275715.93639999,\n" +
                "      \"volume24a\": 20011467.00340037,\n" +
                "      \"csupply\": \"12013965609.00\",\n" +
                "      \"tsupply\": \"21000000000\",\n" +
                "      \"msupply\": \"21000000000\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"32764\",\n" +
                "      \"symbol\": \"SEELE\",\n" +
                "      \"name\": \"Seele\",\n" +
                "      \"nameid\": \"seele\",\n" +
                "      \"rank\": 79,\n" +
                "      \"price_usd\": \"0.048108\",\n" +
                "      \"percent_change_24h\": \"2.10\",\n" +
                "      \"percent_change_1h\": \"-0.10\",\n" +
                "      \"percent_change_7d\": \"-2.33\",\n" +
                "      \"price_btc\": \"0.000007\",\n" +
                "      \"market_cap_usd\": \"33328376.85\",\n" +
                "      \"volume24\": 11278189.173531808,\n" +
                "      \"volume24a\": 13478485.821404563,\n" +
                "      \"csupply\": \"692776387.00\",\n" +
                "      \"tsupply\": \"1000000000\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"131\",\n" +
                "      \"symbol\": \"ARDR\",\n" +
                "      \"name\": \"Ardor\",\n" +
                "      \"nameid\": \"ardor\",\n" +
                "      \"rank\": 80,\n" +
                "      \"price_usd\": \"0.033082\",\n" +
                "      \"percent_change_24h\": \"9.37\",\n" +
                "      \"percent_change_1h\": \"0.54\",\n" +
                "      \"percent_change_7d\": \"0.39\",\n" +
                "      \"price_btc\": \"0.000005\",\n" +
                "      \"market_cap_usd\": \"33048467.65\",\n" +
                "      \"volume24\": 579725.6889511767,\n" +
                "      \"volume24a\": 547506.0791313401,\n" +
                "      \"csupply\": \"998999495.00\",\n" +
                "      \"tsupply\": \"998999495\",\n" +
                "      \"msupply\": \"998999495\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"32334\",\n" +
                "      \"symbol\": \"ZIL\",\n" +
                "      \"name\": \"Zilliqa\",\n" +
                "      \"nameid\": \"zilliqa\",\n" +
                "      \"rank\": 81,\n" +
                "      \"price_usd\": \"0.003784\",\n" +
                "      \"percent_change_24h\": \"5.36\",\n" +
                "      \"percent_change_1h\": \"-0.59\",\n" +
                "      \"percent_change_7d\": \"-0.23\",\n" +
                "      \"price_btc\": \"5.86E-7\",\n" +
                "      \"market_cap_usd\": \"32869017.95\",\n" +
                "      \"volume24\": 6240324.953328698,\n" +
                "      \"volume24a\": 5870224.585415617,\n" +
                "      \"csupply\": \"8687360058.00\",\n" +
                "      \"tsupply\": \"12600000000\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"156\",\n" +
                "      \"symbol\": \"GNT\",\n" +
                "      \"name\": \"Golem\",\n" +
                "      \"nameid\": \"golem-network-tokens\",\n" +
                "      \"rank\": 82,\n" +
                "      \"price_usd\": \"0.033795\",\n" +
                "      \"percent_change_24h\": \"6.41\",\n" +
                "      \"percent_change_1h\": \"0.48\",\n" +
                "      \"percent_change_7d\": \"-0.07\",\n" +
                "      \"price_btc\": \"0.000005\",\n" +
                "      \"market_cap_usd\": \"32593124.76\",\n" +
                "      \"volume24\": 2371200.048448543,\n" +
                "      \"volume24a\": 1759489.9678284673,\n" +
                "      \"csupply\": \"964450000.00\",\n" +
                "      \"tsupply\": \"1000000000\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"2765\",\n" +
                "      \"symbol\": \"DATA\",\n" +
                "      \"name\": \"Streamr DATAcoin\",\n" +
                "      \"nameid\": \"streamr-datacoin\",\n" +
                "      \"rank\": 83,\n" +
                "      \"price_usd\": \"0.046343\",\n" +
                "      \"percent_change_24h\": \"17.40\",\n" +
                "      \"percent_change_1h\": \"-0.62\",\n" +
                "      \"percent_change_7d\": \"79.49\",\n" +
                "      \"price_btc\": \"0.000007\",\n" +
                "      \"market_cap_usd\": \"31381554.25\",\n" +
                "      \"volume24\": 6179716.581567251,\n" +
                "      \"volume24a\": 2119159.9592199586,\n" +
                "      \"csupply\": \"677154514.00\",\n" +
                "      \"tsupply\": \"987154514\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"32226\",\n" +
                "      \"symbol\": \"ELF\",\n" +
                "      \"name\": \"aelf\",\n" +
                "      \"nameid\": \"aelf\",\n" +
                "      \"rank\": 84,\n" +
                "      \"price_usd\": \"0.061876\",\n" +
                "      \"percent_change_24h\": \"15.09\",\n" +
                "      \"percent_change_1h\": \"1.04\",\n" +
                "      \"percent_change_7d\": \"11.01\",\n" +
                "      \"price_btc\": \"0.000010\",\n" +
                "      \"market_cap_usd\": \"30924157.88\",\n" +
                "      \"volume24\": 41529536.95372255,\n" +
                "      \"volume24a\": 23848793.672663834,\n" +
                "      \"csupply\": \"499780000.00\",\n" +
                "      \"tsupply\": \"499780000\",\n" +
                "      \"msupply\": \"1000000000\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"33548\",\n" +
                "      \"symbol\": \"NEX\",\n" +
                "      \"name\": \"Nash Exchange\",\n" +
                "      \"nameid\": \"nash-exchange\",\n" +
                "      \"rank\": 85,\n" +
                "      \"price_usd\": \"0.777294\",\n" +
                "      \"percent_change_24h\": \"21.57\",\n" +
                "      \"percent_change_1h\": \"-0.18\",\n" +
                "      \"percent_change_7d\": \"16.27\",\n" +
                "      \"price_btc\": \"0.000120\",\n" +
                "      \"market_cap_usd\": \"28135460.93\",\n" +
                "      \"volume24\": 3450188.378464302,\n" +
                "      \"volume24a\": 4192274.3629639074,\n" +
                "      \"csupply\": \"36196678.00\",\n" +
                "      \"tsupply\": \"56296100\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"32238\",\n" +
                "      \"symbol\": \"WAX\",\n" +
                "      \"name\": \"WAX\",\n" +
                "      \"nameid\": \"wax\",\n" +
                "      \"rank\": 86,\n" +
                "      \"price_usd\": \"0.029561\",\n" +
                "      \"percent_change_24h\": \"3.57\",\n" +
                "      \"percent_change_1h\": \"0.05\",\n" +
                "      \"percent_change_7d\": \"-4.40\",\n" +
                "      \"price_btc\": \"0.000005\",\n" +
                "      \"market_cap_usd\": \"27870765.75\",\n" +
                "      \"volume24\": 100574.74989765436,\n" +
                "      \"volume24a\": 100415.33815866824,\n" +
                "      \"csupply\": \"942821662.00\",\n" +
                "      \"tsupply\": \"1850000000\",\n" +
                "      \"msupply\": \"1850000000\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"2732\",\n" +
                "      \"symbol\": \"GXS\",\n" +
                "      \"name\": \"GXChain\",\n" +
                "      \"nameid\": \"gxchain\",\n" +
                "      \"rank\": 87,\n" +
                "      \"price_usd\": \"0.420573\",\n" +
                "      \"percent_change_24h\": \"5.01\",\n" +
                "      \"percent_change_1h\": \"1.39\",\n" +
                "      \"percent_change_7d\": \"34.55\",\n" +
                "      \"price_btc\": \"0.000065\",\n" +
                "      \"market_cap_usd\": \"27337246.91\",\n" +
                "      \"volume24\": 304531.99185111927,\n" +
                "      \"volume24a\": 481539.91585276544,\n" +
                "      \"csupply\": \"65000000.00\",\n" +
                "      \"tsupply\": \"100000000\",\n" +
                "      \"msupply\": \"100000000\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"2731\",\n" +
                "      \"symbol\": \"AE\",\n" +
                "      \"name\": \"Aeternity\",\n" +
                "      \"nameid\": \"aeternity\",\n" +
                "      \"rank\": 88,\n" +
                "      \"price_usd\": \"0.097332\",\n" +
                "      \"percent_change_24h\": \"6.50\",\n" +
                "      \"percent_change_1h\": \"0.22\",\n" +
                "      \"percent_change_7d\": \"1.39\",\n" +
                "      \"price_btc\": \"0.000015\",\n" +
                "      \"market_cap_usd\": \"27285380.93\",\n" +
                "      \"volume24\": 8765188.693276754,\n" +
                "      \"volume24a\": 6527224.234053292,\n" +
                "      \"csupply\": \"280333087.00\",\n" +
                "      \"tsupply\": \"280333087\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"258\",\n" +
                "      \"symbol\": \"MANA\",\n" +
                "      \"name\": \"Decentraland\",\n" +
                "      \"nameid\": \"decentraland\",\n" +
                "      \"rank\": 89,\n" +
                "      \"price_usd\": \"0.025146\",\n" +
                "      \"percent_change_24h\": \"9.64\",\n" +
                "      \"percent_change_1h\": \"-2.10\",\n" +
                "      \"percent_change_7d\": \"4.18\",\n" +
                "      \"price_btc\": \"0.000004\",\n" +
                "      \"market_cap_usd\": \"26407318.32\",\n" +
                "      \"volume24\": 21118647.40642758,\n" +
                "      \"volume24a\": 16833866.965715174,\n" +
                "      \"csupply\": \"1050141509.00\",\n" +
                "      \"tsupply\": \"2644403343\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"32342\",\n" +
                "      \"symbol\": \"NPXS\",\n" +
                "      \"name\": \"Pundi X\",\n" +
                "      \"nameid\": \"pundi-x\",\n" +
                "      \"rank\": 90,\n" +
                "      \"price_usd\": \"0.000111\",\n" +
                "      \"percent_change_24h\": \"4.35\",\n" +
                "      \"percent_change_1h\": \"0.33\",\n" +
                "      \"percent_change_7d\": \"4.74\",\n" +
                "      \"price_btc\": \"1.72E-8\",\n" +
                "      \"market_cap_usd\": \"26142765.12\",\n" +
                "      \"volume24\": 705558.7947364057,\n" +
                "      \"volume24a\": 702033.3649572664,\n" +
                "      \"csupply\": \"235171468515.00\",\n" +
                "      \"tsupply\": \"280255193861\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"32338\",\n" +
                "      \"symbol\": \"WICC\",\n" +
                "      \"name\": \"WaykiChain\",\n" +
                "      \"nameid\": \"waykichain\",\n" +
                "      \"rank\": 91,\n" +
                "      \"price_usd\": \"0.137932\",\n" +
                "      \"percent_change_24h\": \"5.48\",\n" +
                "      \"percent_change_1h\": \"-0.43\",\n" +
                "      \"percent_change_7d\": \"-8.14\",\n" +
                "      \"price_btc\": \"0.000021\",\n" +
                "      \"market_cap_usd\": \"26069208.17\",\n" +
                "      \"volume24\": 685747.0517920915,\n" +
                "      \"volume24a\": 783423.6852382879,\n" +
                "      \"csupply\": \"189000000.00\",\n" +
                "      \"tsupply\": \"210000000\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"32390\",\n" +
                "      \"symbol\": \"REN\",\n" +
                "      \"name\": \"Republic Protocol\",\n" +
                "      \"nameid\": \"republic-protocol\",\n" +
                "      \"rank\": 92,\n" +
                "      \"price_usd\": \"0.043984\",\n" +
                "      \"percent_change_24h\": \"11.54\",\n" +
                "      \"percent_change_1h\": \"0.07\",\n" +
                "      \"percent_change_7d\": \"14.44\",\n" +
                "      \"price_btc\": \"0.000007\",\n" +
                "      \"market_cap_usd\": \"25873855.18\",\n" +
                "      \"volume24\": 762895.2864727881,\n" +
                "      \"volume24a\": 592425.2247141263,\n" +
                "      \"csupply\": \"588261205.00\",\n" +
                "      \"tsupply\": \"1000000000\",\n" +
                "      \"msupply\": null\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"36419\",\n" +
                "      \"symbol\": \"CVCC\",\n" +
                "      \"name\": \"CryptoVerificationCoin\",\n" +
                "      \"nameid\": \"cryptoverificationcoin\",\n" +
                "      \"rank\": 93,\n" +
                "      \"price_usd\": \"21.96\",\n" +
                "      \"percent_change_24h\": \"15.53\",\n" +
                "      \"percent_change_1h\": \"0.27\",\n" +
                "      \"percent_change_7d\": \"2.43\",\n" +
                "      \"price_btc\": \"0.003402\",\n" +
                "      \"market_cap_usd\": \"25312922.52\",\n" +
                "      \"volume24\": 52456.21681009046,\n" +
                "      \"volume24a\": 0,\n" +
                "      \"csupply\": \"1152727.00\",\n" +
                "      \"tsupply\": \"1152727\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"264\",\n" +
                "      \"symbol\": \"RCN\",\n" +
                "      \"name\": \"Ripio Credit Network\",\n" +
                "      \"nameid\": \"ripiocreditnetwork\",\n" +
                "      \"rank\": 94,\n" +
                "      \"price_usd\": \"0.048605\",\n" +
                "      \"percent_change_24h\": \"0.11\",\n" +
                "      \"percent_change_1h\": \"0.19\",\n" +
                "      \"percent_change_7d\": \"20.99\",\n" +
                "      \"price_btc\": \"0.000008\",\n" +
                "      \"market_cap_usd\": \"23978354.40\",\n" +
                "      \"volume24\": 364719.05944050755,\n" +
                "      \"volume24a\": 321246.77469370444,\n" +
                "      \"csupply\": \"493330791.00\",\n" +
                "      \"tsupply\": \"999942647\",\n" +
                "      \"msupply\": \"1000000000\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"166\",\n" +
                "      \"symbol\": \"RLC\",\n" +
                "      \"name\": \"iExec RLC\",\n" +
                "      \"nameid\": \"rlc\",\n" +
                "      \"rank\": 95,\n" +
                "      \"price_usd\": \"0.297725\",\n" +
                "      \"percent_change_24h\": \"10.65\",\n" +
                "      \"percent_change_1h\": \"0.16\",\n" +
                "      \"percent_change_7d\": \"10.70\",\n" +
                "      \"price_btc\": \"0.000046\",\n" +
                "      \"market_cap_usd\": \"23839060.17\",\n" +
                "      \"volume24\": 413324.34071485844,\n" +
                "      \"volume24a\": 238425.45325606014,\n" +
                "      \"csupply\": \"80070793.00\",\n" +
                "      \"tsupply\": \"86999785\",\n" +
                "      \"msupply\": \" 87000000\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"120\",\n" +
                "      \"symbol\": \"STRAT\",\n" +
                "      \"name\": \"Stratis\",\n" +
                "      \"nameid\": \"stratis\",\n" +
                "      \"rank\": 96,\n" +
                "      \"price_usd\": \"0.238932\",\n" +
                "      \"percent_change_24h\": \"6.65\",\n" +
                "      \"percent_change_1h\": \"0.16\",\n" +
                "      \"percent_change_7d\": \"2.09\",\n" +
                "      \"price_btc\": \"0.000037\",\n" +
                "      \"market_cap_usd\": \"23828483.64\",\n" +
                "      \"volume24\": 328191.01291194663,\n" +
                "      \"volume24a\": 367850.63706199435,\n" +
                "      \"csupply\": \"99729045.00\",\n" +
                "      \"tsupply\": \"99729045\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"2781\",\n" +
                "      \"symbol\": \"LRC\",\n" +
                "      \"name\": \"Loopring\",\n" +
                "      \"nameid\": \"loopring\",\n" +
                "      \"rank\": 97,\n" +
                "      \"price_usd\": \"0.026406\",\n" +
                "      \"percent_change_24h\": \"3.80\",\n" +
                "      \"percent_change_1h\": \"-0.40\",\n" +
                "      \"percent_change_7d\": \"-2.48\",\n" +
                "      \"price_btc\": \"0.000004\",\n" +
                "      \"market_cap_usd\": \"23720301.23\",\n" +
                "      \"volume24\": 2209335.6566007817,\n" +
                "      \"volume24a\": 2163434.2245450304,\n" +
                "      \"csupply\": \"898304697.00\",\n" +
                "      \"tsupply\": \"1374956262\",\n" +
                "      \"msupply\": \"1395076055\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"33536\",\n" +
                "      \"symbol\": \"MATIC\",\n" +
                "      \"name\": \"Matic Network\",\n" +
                "      \"nameid\": \"matic-network\",\n" +
                "      \"rank\": 98,\n" +
                "      \"price_usd\": \"0.010790\",\n" +
                "      \"percent_change_24h\": \"3.95\",\n" +
                "      \"percent_change_1h\": \"0.66\",\n" +
                "      \"percent_change_7d\": \"-1.06\",\n" +
                "      \"price_btc\": \"0.000002\",\n" +
                "      \"market_cap_usd\": \"23470894.98\",\n" +
                "      \"volume24\": 8507263.396085134,\n" +
                "      \"volume24a\": 7377090.919613721,\n" +
                "      \"csupply\": \"2175190262.00\",\n" +
                "      \"tsupply\": \"10000000000\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"95\",\n" +
                "      \"symbol\": \"MAID\",\n" +
                "      \"name\": \"MaidSafeCoin\",\n" +
                "      \"nameid\": \"maidsafecoin\",\n" +
                "      \"rank\": 99,\n" +
                "      \"price_usd\": \"0.051851\",\n" +
                "      \"percent_change_24h\": \"-3.74\",\n" +
                "      \"percent_change_1h\": \"-1.67\",\n" +
                "      \"percent_change_7d\": \"-4.71\",\n" +
                "      \"price_btc\": \"0.000008\",\n" +
                "      \"market_cap_usd\": \"23465336.03\",\n" +
                "      \"volume24\": 151553.65410943772,\n" +
                "      \"volume24a\": 147555.1061683986,\n" +
                "      \"csupply\": \"452552412.00\",\n" +
                "      \"tsupply\": \"452552412\",\n" +
                "      \"msupply\": \"\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": \"33764\",\n" +
                "      \"symbol\": \"RIF\",\n" +
                "      \"name\": \"RIF Token\",\n" +
                "      \"nameid\": \"rif-token\",\n" +
                "      \"rank\": 100,\n" +
                "      \"price_usd\": \"0.048879\",\n" +
                "      \"percent_change_24h\": \"7.36\",\n" +
                "      \"percent_change_1h\": \"0.37\",\n" +
                "      \"percent_change_7d\": \"6.94\",\n" +
                "      \"price_btc\": \"0.000008\",\n" +
                "      \"market_cap_usd\": \"23363285.64\",\n" +
                "      \"volume24\": 9997527.002168821,\n" +
                "      \"volume24a\": 8248318.5991313225,\n" +
                "      \"csupply\": \"477980957.00\",\n" +
                "      \"tsupply\": \"1000000000\",\n" +
                "      \"msupply\": \"\"\n" +
                "    }\n" +
                "  ],\n" +
                "  \"info\": {\n" +
                "    \"coins_num\": 3982,\n" +
                "    \"time\": 1585628141\n" +
                "  }\n" +
                "}";




    public List<Coin> getData() {
        return data;
    }

    public void setData(List<Coin> data) {
        this.data = data;
    }

    public Info getInfo() {
        return info;
    }

    public void setInfo(Info info) {
        this.info = info;
    }

}